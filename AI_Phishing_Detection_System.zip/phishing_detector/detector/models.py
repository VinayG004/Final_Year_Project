from django.db import models


class URLScan(models.Model):
    """Stores the result of every URL phishing scan performed by a user."""

    RESULT_CHOICES = [
        ('Phishing', 'Phishing'),
        ('Legitimate', 'Legitimate'),
    ]
    RISK_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    url = models.TextField()
    prediction = models.CharField(max_length=20, choices=RESULT_CHOICES)
    risk_score = models.FloatField(help_text="Risk score as a percentage (0-100)")
    risk_level = models.CharField(max_length=10, choices=RISK_CHOICES)
    suspicious_features = models.TextField(
        blank=True, help_text="Comma separated list of suspicious features detected"
    )
    scanned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-scanned_at']
        verbose_name = "URL Scan"
        verbose_name_plural = "URL Scans"

    def __str__(self):
        return f"{self.url[:50]} -> {self.prediction} ({self.risk_score}%)"


class EmailScan(models.Model):
    """Stores the result of every email phishing scan performed by a user."""

    RESULT_CHOICES = [
        ('Phishing', 'Phishing'),
        ('Legitimate', 'Legitimate'),
    ]
    RISK_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    email_text = models.TextField()
    prediction = models.CharField(max_length=20, choices=RESULT_CHOICES)
    risk_score = models.FloatField(help_text="Risk score as a percentage (0-100)")
    risk_level = models.CharField(max_length=10, choices=RISK_CHOICES)
    scanned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-scanned_at']
        verbose_name = "Email Scan"
        verbose_name_plural = "Email Scans"

    def __str__(self):
        return f"{self.email_text[:50]} -> {self.prediction} ({self.risk_score}%)"
