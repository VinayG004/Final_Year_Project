"""
generate_sample_data.py
------------------------
Generates small SAMPLE datasets (url_dataset.csv and email_dataset.csv)
for demonstration / college-project purposes. In a real project you
would replace these with a larger, real-world labeled dataset
(e.g. from PhishTank, Kaggle phishing URL datasets, or Enron email +
phishing corpora).

Run this once before training:
    python detector/ml/datasets/generate_sample_data.py
"""

import csv
import os
import random

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------
# 1. URL DATASET
# ---------------------------------------------------------------
legit_domains = [
    'google.com', 'github.com', 'wikipedia.org', 'amazon.com', 'microsoft.com',
    'apple.com', 'stackoverflow.com', 'python.org', 'djangoproject.com',
    'nytimes.com', 'bbc.com', 'linkedin.com', 'reddit.com', 'youtube.com',
    'spotify.com', 'dropbox.com', 'wordpress.org', 'mozilla.org',
]
legit_paths = ['', '/about', '/products', '/docs/intro', '/search?q=news',
               '/user/profile', '/blog/2024/article', '/contact', '/help']

phishing_templates = [
    "http://{word}-login-verify.{tld}/secure/account/{rand}",
    "http://192.168.{a}.{b}/bank/confirm.html",
    "http://{word}.update-billing-{rand}.tk/login",
    "https://secure-{word}account.{tld}/verify?user=login",
    "http://{word}-{word2}.free-offer.{tld}/confirm/password",
    "http://paypal-{word}.{tld}/login/secure-account-verify",
    "http://{rand}.{word}-bank-secure.{tld}/update/password",
    "http://account-{word}.{tld}@{word2}.com/login",
]
words = ['my', 'user', 'client', 'app', 'web', 'online', 'support', 'helpdesk']
tlds = ['tk', 'xyz', 'top', 'club', 'info', 'cc']


def rand_url(template):
    return template.format(
        word=random.choice(words), word2=random.choice(words),
        tld=random.choice(tlds), rand=random.randint(100, 9999),
        a=random.randint(1, 255), b=random.randint(1, 255),
    )


rows = []
for d in legit_domains:
    for p in legit_paths:
        rows.append((f"https://www.{d}{p}", 0))  # 0 = legitimate

for _ in range(180):
    t = random.choice(phishing_templates)
    rows.append((rand_url(t), 1))  # 1 = phishing

random.shuffle(rows)

with open(os.path.join(BASE_DIR, 'url_dataset.csv'), 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['url', 'label'])  # label: 1 = phishing, 0 = legitimate
    writer.writerows(rows)

print(f"url_dataset.csv created with {len(rows)} rows.")

# ---------------------------------------------------------------
# 2. EMAIL DATASET
# ---------------------------------------------------------------
phishing_emails = [
    "Dear customer, your account has been suspended. Verify your account immediately by clicking the link below.",
    "URGENT: Your bank account will be locked. Confirm your password and billing details now.",
    "Congratulations! You have won a free gift card. Claim your offer now before it expires.",
    "We noticed suspicious login activity. Please update your password to secure your account.",
    "Your PayPal account is limited. Login and verify your identity to restore access.",
    "Final notice: confirm your billing information or your subscription will be cancelled today.",
    "Click here to verify your email account or it will be permanently deleted within 24 hours.",
    "Your package could not be delivered. Confirm your address and pay a small fee to release it.",
    "Security alert: unusual sign-in detected. Verify now to avoid account suspension.",
    "You have an unclaimed refund. Login to your bank account to confirm and receive payment.",
    "Action required: update your payment method to avoid service interruption immediately.",
    "Dear user, your password expires today. Click the secure link to reset it right now.",
]

legit_emails = [
    "Hi team, please find attached the meeting notes from yesterday's sync. Let me know if I missed anything.",
    "Thanks for your order! Your package has shipped and will arrive in 3-5 business days.",
    "Reminder: our monthly newsletter is now available on the website. Enjoy the read!",
    "Hello, I wanted to follow up on our conversation last week regarding the project timeline.",
    "Your invoice for this month is attached. Please let us know if you have any questions.",
    "Welcome to our community! Here are some tips to get started with your new account.",
    "Hi, just checking in to see how the new feature rollout is going on your end.",
    "Your flight booking is confirmed. Check-in opens 24 hours before departure.",
    "Here is the weekly report summarizing our team's progress and upcoming milestones.",
    "Thank you for subscribing to our blog. We will send updates whenever we publish new posts.",
    "Hi, attaching the document you requested yesterday during our call. Have a great day.",
    "Your appointment has been scheduled for next Tuesday at 10 AM. See you then.",
]

rows2 = [(t, 1) for t in phishing_emails] + [(t, 0) for t in legit_emails]
random.shuffle(rows2)

with open(os.path.join(BASE_DIR, 'email_dataset.csv'), 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['email_text', 'label'])  # label: 1 = phishing, 0 = legitimate
    writer.writerows(rows2)

print(f"email_dataset.csv created with {len(rows2)} rows.")
