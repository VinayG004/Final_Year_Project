"""
train_email_model.py
----------------------
Trains a text classification model (TF-IDF + Logistic Regression) to
detect phishing emails from raw email text, and saves both the
fitted vectorizer and the trained model.

Outputs:
    detector/ml/models/email_model.pkl
    detector/ml/models/email_vectorizer.pkl

Run from project root:
    python detector/ml/train_email_model.py
"""

import os
import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, 'datasets', 'email_dataset.csv')
MODEL_DIR = os.path.join(BASE_DIR, 'models')
MODEL_PATH = os.path.join(MODEL_DIR, 'email_model.pkl')
VECTORIZER_PATH = os.path.join(MODEL_DIR, 'email_vectorizer.pkl')


def main():
    os.makedirs(MODEL_DIR, exist_ok=True)

    if not os.path.exists(DATASET_PATH):
        print("Dataset not found. Run datasets/generate_sample_data.py first.")
        return

    # 1. Load dataset (columns: email_text, label) label: 1 = phishing, 0 = legitimate
    df = pd.read_csv(DATASET_PATH)
    print(f"Loaded {len(df)} email rows.")

    X_text = df['email_text']
    y = df['label']

    # 2. TF-IDF vectorization of email text
    vectorizer = TfidfVectorizer(
        stop_words='english',
        max_features=3000,
        ngram_range=(1, 2),
    )
    X = vectorizer.fit_transform(X_text)

    # 3. Train/test split (small demo dataset -> no stratify safety check)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    # 4. Train Logistic Regression classifier
    model = LogisticRegression(max_iter=1000, class_weight='balanced')
    model.fit(X_train, y_train)

    # 5. Evaluate
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\nTest Accuracy: {acc * 100:.2f}%\n")
    print(classification_report(y_test, y_pred, target_names=['Legitimate', 'Phishing'], zero_division=0))

    # 6. Save model + vectorizer with joblib
    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)
    print(f"\nModel saved to {MODEL_PATH}")
    print(f"Vectorizer saved to {VECTORIZER_PATH}")


if __name__ == '__main__':
    main()
