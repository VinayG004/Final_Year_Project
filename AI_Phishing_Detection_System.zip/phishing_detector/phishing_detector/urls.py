"""
Main URL configuration for the phishing_detector project.
Includes the detector app's URLs and the Django admin site.
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('detector.urls')),  # All app routes live in detector/urls.py
]
