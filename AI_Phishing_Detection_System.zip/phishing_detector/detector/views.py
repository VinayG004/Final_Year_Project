"""
views.py
---------
Views for the detector app:
- home          : landing page
- url_scan      : scan a URL, show result
- email_scan    : scan email text, show result
- dashboard     : statistics + Chart.js graph
- history       : table of all past scans
"""

import json
from django.shortcuts import render
from django.db.models import Count

from .forms import URLScanForm, EmailScanForm
from .models import URLScan, EmailScan
from .ml_utils import predict_url, predict_email


def home(request):
    """Landing page with project intro and quick links."""
    return render(request, 'detector/home.html')


def url_scan(request):
    """Handles URL input, runs the ML model, saves & displays result."""
    result = None
    form = URLScanForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        url = form.cleaned_data['url']
        try:
            prediction_data = predict_url(url)
        except RuntimeError as e:
            return render(request, 'detector/url_scan.html', {
                'form': form,
                'error': str(e),
            })

        # Save scan result to the database
        URLScan.objects.create(
            url=url,
            prediction=prediction_data['prediction'],
            risk_score=prediction_data['risk_score'],
            risk_level=prediction_data['risk_level'],
            suspicious_features=', '.join(prediction_data['suspicious_features']),
        )

        result = {
            'input': url,
            'prediction': prediction_data['prediction'],
            'risk_score': prediction_data['risk_score'],
            'risk_level': prediction_data['risk_level'],
            'suspicious_features': prediction_data['suspicious_features'],
        }

    return render(request, 'detector/url_scan.html', {'form': form, 'result': result})


def email_scan(request):
    """Handles email text input, runs the ML model, saves & displays result."""
    result = None
    form = EmailScanForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        email_text = form.cleaned_data['email_text']
        try:
            prediction_data = predict_email(email_text)
        except RuntimeError as e:
            return render(request, 'detector/email_scan.html', {
                'form': form,
                'error': str(e),
            })

        # Save scan result to the database
        EmailScan.objects.create(
            email_text=email_text,
            prediction=prediction_data['prediction'],
            risk_score=prediction_data['risk_score'],
            risk_level=prediction_data['risk_level'],
        )

        result = {
            'input': email_text,
            'prediction': prediction_data['prediction'],
            'risk_score': prediction_data['risk_score'],
            'risk_level': prediction_data['risk_level'],
        }

    return render(request, 'detector/email_scan.html', {'form': form, 'result': result})


def dashboard(request):
    """Shows aggregate stats and a phishing-vs-legitimate Chart.js graph."""
    total_url_scans = URLScan.objects.count()
    total_email_scans = EmailScan.objects.count()
    total_scans = total_url_scans + total_email_scans

    total_phishing = (
        URLScan.objects.filter(prediction='Phishing').count()
        + EmailScan.objects.filter(prediction='Phishing').count()
    )
    total_legitimate = total_scans - total_phishing

    high_risk_scans = (
        URLScan.objects.filter(risk_level='High').count()
        + EmailScan.objects.filter(risk_level='High').count()
    )

    # Build a combined "recent scans" list (last 8 of each, merged & sorted)
    recent_url = list(URLScan.objects.all()[:8].values(
        'url', 'prediction', 'risk_score', 'risk_level', 'scanned_at'
    ))
    for r in recent_url:
        r['type'] = 'URL'
        r['input_display'] = r.pop('url')

    recent_email = list(EmailScan.objects.all()[:8].values(
        'email_text', 'prediction', 'risk_score', 'risk_level', 'scanned_at'
    ))
    for r in recent_email:
        r['type'] = 'Email'
        r['input_display'] = r.pop('email_text')[:60]

    recent_scans = sorted(
        recent_url + recent_email, key=lambda x: x['scanned_at'], reverse=True
    )[:10]

    chart_data = {
        'labels': ['Phishing', 'Legitimate'],
        'values': [total_phishing, total_legitimate],
    }

    context = {
        'total_scans': total_scans,
        'total_phishing': total_phishing,
        'total_legitimate': total_legitimate,
        'high_risk_scans': high_risk_scans,
        'recent_scans': recent_scans,
        'chart_data_json': json.dumps(chart_data),
    }
    return render(request, 'detector/dashboard.html', context)


def history(request):
    """Displays a full table of every URL and Email scan ever performed."""
    url_scans = list(URLScan.objects.all().values(
        'url', 'prediction', 'risk_score', 'scanned_at'
    ))
    for r in url_scans:
        r['type'] = 'URL'
        r['input_display'] = r.pop('url')

    email_scans = list(EmailScan.objects.all().values(
        'email_text', 'prediction', 'risk_score', 'scanned_at'
    ))
    for r in email_scans:
        r['type'] = 'Email'
        r['input_display'] = r.pop('email_text')[:80]

    all_scans = sorted(
        url_scans + email_scans, key=lambda x: x['scanned_at'], reverse=True
    )

    return render(request, 'detector/history.html', {'all_scans': all_scans})
