"""
ml_utils.py
------------
Helper functions used by Django views to load the trained ML models
(once, at module import time) and run predictions for URLs and emails.
Also contains the risk score -> risk level mapping logic.
"""

import os
import joblib
import pandas as pd
from django.conf import settings

from detector.ml.feature_extraction import (
    extract_url_features,
    get_suspicious_feature_labels,
    FEATURE_NAMES,
)

MODEL_DIR = settings.ML_MODELS_DIR

# ----------------------------------------------------------------
# Load models once at startup (faster than reloading on every request)
# ----------------------------------------------------------------
_url_model = None
_email_model = None
_email_vectorizer = None


def _load_models():
    """Lazily loads ML models from disk the first time they're needed."""
    global _url_model, _email_model, _email_vectorizer

    url_model_path = os.path.join(MODEL_DIR, 'url_model.pkl')
    email_model_path = os.path.join(MODEL_DIR, 'email_model.pkl')
    email_vec_path = os.path.join(MODEL_DIR, 'email_vectorizer.pkl')

    if _url_model is None and os.path.exists(url_model_path):
        _url_model = joblib.load(url_model_path)

    if _email_model is None and os.path.exists(email_model_path):
        _email_model = joblib.load(email_model_path)

    if _email_vectorizer is None and os.path.exists(email_vec_path):
        _email_vectorizer = joblib.load(email_vec_path)


def risk_level_from_score(score: float) -> str:
    """Maps a numeric risk score (0-100) to a Low / Medium / High label."""
    if score < 40:
        return 'Low'
    elif score < 70:
        return 'Medium'
    return 'High'


def predict_url(url: str) -> dict:
    """
    Runs the trained Random Forest model on a URL and returns a dict with:
    prediction, risk_score (0-100), risk_level, suspicious_features (list)
    """
    _load_models()
    if _url_model is None:
        raise RuntimeError(
            "URL model not found. Run: python detector/ml/train_url_model.py"
        )

    features = extract_url_features(url)
    X = pd.DataFrame([features], columns=FEATURE_NAMES)

    # predict_proba returns [[prob_legit, prob_phish]] since classes are 0/1
    proba = _url_model.predict_proba(X)[0]
    classes = list(_url_model.classes_)
    phishing_index = classes.index(1) if 1 in classes else 1
    phishing_prob = proba[phishing_index]

    risk_score = round(float(phishing_prob) * 100, 2)
    prediction = 'Phishing' if phishing_prob >= 0.5 else 'Legitimate'
    risk_level = risk_level_from_score(risk_score)
    suspicious_features = get_suspicious_feature_labels(url)

    return {
        'prediction': prediction,
        'risk_score': risk_score,
        'risk_level': risk_level,
        'suspicious_features': suspicious_features,
    }


def predict_email(email_text: str) -> dict:
    """
    Runs the trained TF-IDF + Logistic Regression model on email text
    and returns a dict with: prediction, risk_score (0-100), risk_level
    """
    _load_models()
    if _email_model is None or _email_vectorizer is None:
        raise RuntimeError(
            "Email model not found. Run: python detector/ml/train_email_model.py"
        )

    X = _email_vectorizer.transform([email_text])
    proba = _email_model.predict_proba(X)[0]
    classes = list(_email_model.classes_)
    phishing_index = classes.index(1) if 1 in classes else 1
    phishing_prob = proba[phishing_index]

    risk_score = round(float(phishing_prob) * 100, 2)
    prediction = 'Phishing' if phishing_prob >= 0.5 else 'Legitimate'
    risk_level = risk_level_from_score(risk_score)

    return {
        'prediction': prediction,
        'risk_score': risk_score,
        'risk_level': risk_level,
    }
