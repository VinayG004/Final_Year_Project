"""
urls.py
--------
URL routes for the detector app.
"""

from django.urls import path
from . import views

app_name = 'detector'

urlpatterns = [
    path('', views.home, name='home'),
    path('scan/url/', views.url_scan, name='url_scan'),
    path('scan/email/', views.email_scan, name='email_scan'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('history/', views.history, name='history'),
]
