/* dashboard.js
   Renders the Phishing vs Legitimate doughnut chart on the dashboard
   page using Chart.js. Expects a global `phishingChartData` object
   (set inline in dashboard.html) of the form:
   { labels: [...], values: [...] }
*/

document.addEventListener('DOMContentLoaded', function () {
    const ctxEl = document.getElementById('phishingChart');
    if (!ctxEl || typeof phishingChartData === 'undefined') return;

    const ctx = ctxEl.getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: phishingChartData.labels,
            datasets: [{
                data: phishingChartData.values,
                backgroundColor: ['#E53E5C', '#16B364'],
                borderWidth: 0,
                hoverOffset: 6,
            }],
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 14, font: { size: 13 } } },
            },
            cutout: '65%',
        },
    });
});
