"""
forms.py
---------
Simple Django forms for the URL and Email scan input pages.
"""

from django import forms


class URLScanForm(forms.Form):
    url = forms.CharField(
        label='Enter URL',
        max_length=2000,
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': 'e.g. https://example.com/login',
        }),
    )


class EmailScanForm(forms.Form):
    email_text = forms.CharField(
        label='Paste Email Content',
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 8,
            'placeholder': 'Paste the full email text here...',
        }),
    )
