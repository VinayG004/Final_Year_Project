# AI-Based Phishing Detection System

A Django web application that uses Machine Learning to detect phishing
URLs and emails, shows a risk score / risk level, and keeps a full
scan history. Built for a college final-year project demonstration.

## Tech Stack
Python, Django, SQLite, scikit-learn, pandas, joblib, Bootstrap 5, Chart.js

## Folder Structure
```
phishing_detector/
├── manage.py
├── requirements.txt
├── db.sqlite3                     (created after migrate)
├── phishing_detector/             # Django project settings
│   ├── settings.py
│   ├── urls.py
│   └── ...
├── detector/                      # Main app
│   ├── models.py                  # URLScan, EmailScan
│   ├── views.py                   # home, url_scan, email_scan, dashboard, history
│   ├── urls.py
│   ├── forms.py
│   ├── admin.py
│   ├── ml_utils.py                # loads models + predicts (used by views)
│   └── ml/
│       ├── feature_extraction.py  # URL feature engineering
│       ├── train_url_model.py     # trains Random Forest -> url_model.pkl
│       ├── train_email_model.py   # trains TF-IDF + LogisticRegression
│       ├── datasets/
│       │   ├── generate_sample_data.py
│       │   ├── url_dataset.csv
│       │   └── email_dataset.csv
│       └── models/                # saved .pkl files
│           ├── url_model.pkl
│           ├── email_model.pkl
│           └── email_vectorizer.pkl
├── templates/detector/            # HTML templates (Bootstrap 5)
│   ├── base.html, home.html, url_scan.html, email_scan.html,
│   │   dashboard.html, history.html
└── static/detector/
    ├── css/style.css
    └── js/dashboard.js
```

## 1. Installation

```bash
# Create & activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 2. Generate Sample Datasets (already included, but you can regenerate)

```bash
python detector/ml/datasets/generate_sample_data.py
```
This creates `url_dataset.csv` (URL, label) and `email_dataset.csv`
(email_text, label) where label 1 = Phishing, 0 = Legitimate. Replace
these with a larger real-world dataset for better accuracy.

## 3. Train the ML Models

```bash
python detector/ml/train_url_model.py
python detector/ml/train_email_model.py
```
This saves `url_model.pkl`, `email_model.pkl`, and
`email_vectorizer.pkl` into `detector/ml/models/`. The Django app
loads these automatically — re-run these scripts any time you want to
retrain with new data.

## 4. Django Setup

```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser   # for the Admin Dashboard at /admin/
```

## 5. Run the Server

```bash
python manage.py runserver
```
Visit **http://127.0.0.1:8000/**

## Pages
| URL              | Description                              |
|-------------------|-------------------------------------------|
| `/`                | Home page                                 |
| `/scan/url/`       | URL phishing scan                         |
| `/scan/email/`     | Email phishing scan                       |
| `/dashboard/`      | Stats + Chart.js phishing vs legit chart  |
| `/history/`        | Full scan history table                   |
| `/admin/`          | Django Admin (manage scans directly)      |

## How It Works
**URL detection:** `feature_extraction.py` converts a URL into 9
numeric features (length, dot/hyphen/slash counts, HTTPS, `@` symbol,
IP address usage, suspicious keyword count, domain length). A trained
**Random Forest Classifier** predicts the phishing probability, which
becomes the risk score.

**Email detection:** Raw email text is vectorized with **TF-IDF**
(unigrams + bigrams) and classified using **Logistic Regression**.

**Risk Level mapping:** score < 40% → Low, 40–69% → Medium, ≥ 70% → High.

Every scan (URL or Email) is saved to SQLite via the `URLScan` and
`EmailScan` models, and shown in the Dashboard and History pages.

## Notes for Improving the Project
- Replace the small sample CSVs with real phishing datasets (PhishTank,
  Kaggle "Phishing Website Dataset", Enron + phishing email corpora)
  for production-grade accuracy.
- Add user authentication so each user only sees their own scan history.
- Add a confidence/explainability view (e.g. feature importance chart).
