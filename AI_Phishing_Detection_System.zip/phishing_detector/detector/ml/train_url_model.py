"""
train_url_model.py
--------------------
Trains a Random Forest Classifier to detect phishing URLs using
hand-crafted features (see feature_extraction.py) and saves the
trained model to detector/ml/models/url_model.pkl

Run from project root:
    python detector/ml/train_url_model.py
"""

import os
import sys
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Allow importing feature_extraction.py whether run as a script or module
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from feature_extraction import extract_url_features, FEATURE_NAMES  # noqa: E402

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, 'datasets', 'url_dataset.csv')
MODEL_DIR = os.path.join(BASE_DIR, 'models')
MODEL_PATH = os.path.join(MODEL_DIR, 'url_model.pkl')


def main():
    os.makedirs(MODEL_DIR, exist_ok=True)

    if not os.path.exists(DATASET_PATH):
        print("Dataset not found. Run datasets/generate_sample_data.py first.")
        return

    # 1. Load dataset (columns: url, label)  label: 1 = phishing, 0 = legitimate
    df = pd.read_csv(DATASET_PATH)
    print(f"Loaded {len(df)} URL rows.")

    # 2. Extract features for every URL
    feature_rows = [extract_url_features(u) for u in df['url']]
    X = pd.DataFrame(feature_rows, columns=FEATURE_NAMES)
    y = df['label']

    # 3. Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 4. Train Random Forest Classifier
    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=10,
        random_state=42,
        class_weight='balanced',
    )
    model.fit(X_train, y_train)

    # 5. Evaluate
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\nTest Accuracy: {acc * 100:.2f}%\n")
    print(classification_report(y_test, y_pred, target_names=['Legitimate', 'Phishing']))

    # 6. Save model with joblib
    joblib.dump(model, MODEL_PATH)
    print(f"\nModel saved to {MODEL_PATH}")


if __name__ == '__main__':
    main()
