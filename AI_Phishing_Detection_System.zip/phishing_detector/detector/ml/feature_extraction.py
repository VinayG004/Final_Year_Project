"""
feature_extraction.py
----------------------
Extracts numeric features from a URL string for the phishing
detection ML model (used by both training and prediction code).

Features extracted:
1. url_length            - total length of the URL
2. dot_count             - number of '.' characters
3. hyphen_count          - number of '-' characters
4. slash_count           - number of '/' characters
5. has_https             - 1 if URL uses https, else 0
6. has_at_symbol         - 1 if '@' is present (used to obfuscate real domain)
7. has_ip                - 1 if the domain is a raw IP address
8. suspicious_word_count - count of phishing-related keywords
9. domain_length         - length of the domain part of the URL
"""

import re
from urllib.parse import urlparse

# Common words used in phishing URLs to create urgency / trust
SUSPICIOUS_WORDS = [
    'login', 'verify', 'update', 'secure', 'account',
    'bank', 'password', 'free', 'offer', 'confirm', 'billing',
]

IP_PATTERN = re.compile(
    r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}'
    r'(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
)

FEATURE_NAMES = [
    'url_length', 'dot_count', 'hyphen_count', 'slash_count',
    'has_https', 'has_at_symbol', 'has_ip',
    'suspicious_word_count', 'domain_length',
]


def _get_domain(url: str) -> str:
    """Safely extract the domain/netloc part of a URL."""
    try:
        parsed = urlparse(url if '://' in url else f'http://{url}')
        domain = parsed.netloc
        # Remove port number if present, e.g. example.com:8080
        domain = domain.split(':')[0]
        return domain
    except Exception:
        return ''


def extract_url_features(url: str) -> dict:
    """
    Extracts a dictionary of numeric features from a single URL string.
    Returns a dict so callers can build a DataFrame easily for sklearn.
    """
    url = (url or '').strip()
    domain = _get_domain(url)
    lower_url = url.lower()

    features = {
        'url_length': len(url),
        'dot_count': url.count('.'),
        'hyphen_count': url.count('-'),
        'slash_count': url.count('/'),
        'has_https': 1 if lower_url.startswith('https://') else 0,
        'has_at_symbol': 1 if '@' in url else 0,
        'has_ip': 1 if IP_PATTERN.match(domain) else 0,
        'suspicious_word_count': sum(1 for w in SUSPICIOUS_WORDS if w in lower_url),
        'domain_length': len(domain),
    }
    return features


def get_suspicious_feature_labels(url: str) -> list:
    """
    Returns a human-readable list of suspicious characteristics found in
    the URL. Used to display 'key suspicious features' in the UI.
    """
    feats = extract_url_features(url)
    lower_url = url.lower()
    labels = []

    if feats['has_https'] == 0:
        labels.append('No HTTPS encryption')
    if feats['has_at_symbol']:
        labels.append("Contains '@' symbol (possible domain spoofing)")
    if feats['has_ip']:
        labels.append('Uses raw IP address instead of domain name')
    if feats['suspicious_word_count'] > 0:
        found = [w for w in SUSPICIOUS_WORDS if w in lower_url]
        labels.append(f"Suspicious keyword(s): {', '.join(found)}")
    if feats['url_length'] > 75:
        labels.append('Unusually long URL')
    if feats['hyphen_count'] >= 3:
        labels.append('Excessive hyphens in URL')
    if feats['dot_count'] >= 4:
        labels.append('Excessive sub-domains (many dots)')

    if not labels:
        labels.append('No major suspicious patterns detected')

    return labels


def extract_features_as_list(url: str) -> list:
    """Returns the feature values in a fixed order, ready for model.predict()."""
    feats = extract_url_features(url)
    return [feats[name] for name in FEATURE_NAMES]
