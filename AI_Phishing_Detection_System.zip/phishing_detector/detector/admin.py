"""
admin.py
---------
Registers URLScan and EmailScan with the Django Admin Dashboard so
staff can view, search, and filter all scan history from /admin/.
"""

from django.contrib import admin
from .models import URLScan, EmailScan


@admin.register(URLScan)
class URLScanAdmin(admin.ModelAdmin):
    list_display = ('url', 'prediction', 'risk_score', 'risk_level', 'scanned_at')
    list_filter = ('prediction', 'risk_level')
    search_fields = ('url',)
    ordering = ('-scanned_at',)


@admin.register(EmailScan)
class EmailScanAdmin(admin.ModelAdmin):
    list_display = ('short_text', 'prediction', 'risk_score', 'risk_level', 'scanned_at')
    list_filter = ('prediction', 'risk_level')
    search_fields = ('email_text',)
    ordering = ('-scanned_at',)

    def short_text(self, obj):
        return obj.email_text[:60]
    short_text.short_description = 'Email Text'
